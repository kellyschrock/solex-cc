#!/bin/bash

set -e
set -x

# ./cmavnode -i -v -f cmavnode.conf
./cmavnode -i -v -f cmavnode.slim.conf
